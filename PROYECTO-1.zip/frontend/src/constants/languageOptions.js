export const languageOptions = [
  {
    id: 1,
    name: "YAPL (1.0)",
    label: "YAPL (1.0)",
    value: "java",
  },
];
