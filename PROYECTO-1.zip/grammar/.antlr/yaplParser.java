// Generated from c:\\Users\\raula\\Documents\\RAUL_ANGEL\\UVG_COMPU\\10mo_Semestre\\compiladores\\grammar\\yapl.g4 by ANTLR 4.9.2
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class yaplParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		CLASS=1, ELSE=2, FI=3, IF=4, IN=5, INHERITS=6, ISVOID=7, LOOP=8, POOL=9, 
		THEN=10, WHILE=11, NEW=12, NOT=13, LET=14, TRUE=15, FALSE=16, WS=17, NEWLINE=18, 
		LPAREN=19, RPAREN=20, LBRACE=21, RBRACE=22, COLON=23, SEMICOLON=24, COMMA=25, 
		PERIOD=26, NEGATIVE=27, AT=28, PLUS=29, MINUS=30, MULT=31, DIV=32, LESS_THAN=33, 
		LESS_EQUAL=34, GREATER_THAN=35, GREATER_EQUAL=36, EQUAL=37, FAT_ARROW=38, 
		ASSIGN=39, ERROR=40, COMMENT_BLOCK=41, COMMENT_LINE=42, INT_VAR=43, ID_VAR=44, 
		TYPE_IDENTIFIER=45, STR_VAR=46;
	public static final int
		RULE_program = 0, RULE_classs = 1, RULE_var_typescript = 2, RULE_feature = 3, 
		RULE_formal = 4, RULE_expr = 5;
	private static String[] makeRuleNames() {
		return new String[] {
			"program", "classs", "var_typescript", "feature", "formal", "expr"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, "'true'", "'false'", null, null, "'('", "')'", "'{'", 
			"'}'", "':'", "';'", "','", "'.'", "'~'", "'@'", "'+'", "'-'", "'*'", 
			"'/'", "'<'", "'<='", "'>'", "'>='", "'='", "'=>'", "'<-'", "'ERROR'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "CLASS", "ELSE", "FI", "IF", "IN", "INHERITS", "ISVOID", "LOOP", 
			"POOL", "THEN", "WHILE", "NEW", "NOT", "LET", "TRUE", "FALSE", "WS", 
			"NEWLINE", "LPAREN", "RPAREN", "LBRACE", "RBRACE", "COLON", "SEMICOLON", 
			"COMMA", "PERIOD", "NEGATIVE", "AT", "PLUS", "MINUS", "MULT", "DIV", 
			"LESS_THAN", "LESS_EQUAL", "GREATER_THAN", "GREATER_EQUAL", "EQUAL", 
			"FAT_ARROW", "ASSIGN", "ERROR", "COMMENT_BLOCK", "COMMENT_LINE", "INT_VAR", 
			"ID_VAR", "TYPE_IDENTIFIER", "STR_VAR"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "yapl.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public yaplParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ProgramContext extends ParserRuleContext {
		public List<ClasssContext> classs() {
			return getRuleContexts(ClasssContext.class);
		}
		public ClasssContext classs(int i) {
			return getRuleContext(ClasssContext.class,i);
		}
		public List<TerminalNode> SEMICOLON() { return getTokens(yaplParser.SEMICOLON); }
		public TerminalNode SEMICOLON(int i) {
			return getToken(yaplParser.SEMICOLON, i);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(15); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(12);
				classs();
				setState(13);
				match(SEMICOLON);
				}
				}
				setState(17); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==CLASS );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClasssContext extends ParserRuleContext {
		public TerminalNode CLASS() { return getToken(yaplParser.CLASS, 0); }
		public List<TerminalNode> TYPE_IDENTIFIER() { return getTokens(yaplParser.TYPE_IDENTIFIER); }
		public TerminalNode TYPE_IDENTIFIER(int i) {
			return getToken(yaplParser.TYPE_IDENTIFIER, i);
		}
		public TerminalNode LBRACE() { return getToken(yaplParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(yaplParser.RBRACE, 0); }
		public TerminalNode INHERITS() { return getToken(yaplParser.INHERITS, 0); }
		public List<FeatureContext> feature() {
			return getRuleContexts(FeatureContext.class);
		}
		public FeatureContext feature(int i) {
			return getRuleContext(FeatureContext.class,i);
		}
		public List<TerminalNode> SEMICOLON() { return getTokens(yaplParser.SEMICOLON); }
		public TerminalNode SEMICOLON(int i) {
			return getToken(yaplParser.SEMICOLON, i);
		}
		public ClasssContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_classs; }
	}

	public final ClasssContext classs() throws RecognitionException {
		ClasssContext _localctx = new ClasssContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_classs);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(19);
			match(CLASS);
			setState(20);
			match(TYPE_IDENTIFIER);
			setState(23);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==INHERITS) {
				{
				setState(21);
				match(INHERITS);
				setState(22);
				match(TYPE_IDENTIFIER);
				}
			}

			setState(25);
			match(LBRACE);
			setState(31);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ID_VAR) {
				{
				{
				setState(26);
				feature();
				setState(27);
				match(SEMICOLON);
				}
				}
				setState(33);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(34);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Var_typescriptContext extends ParserRuleContext {
		public Var_typescriptContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var_typescript; }
	 
		public Var_typescriptContext() { }
		public void copyFrom(Var_typescriptContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class AttributesDeclarationContext extends Var_typescriptContext {
		public TerminalNode ID_VAR() { return getToken(yaplParser.ID_VAR, 0); }
		public TerminalNode COLON() { return getToken(yaplParser.COLON, 0); }
		public TerminalNode TYPE_IDENTIFIER() { return getToken(yaplParser.TYPE_IDENTIFIER, 0); }
		public TerminalNode ASSIGN() { return getToken(yaplParser.ASSIGN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public AttributesDeclarationContext(Var_typescriptContext ctx) { copyFrom(ctx); }
	}

	public final Var_typescriptContext var_typescript() throws RecognitionException {
		Var_typescriptContext _localctx = new Var_typescriptContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_var_typescript);
		int _la;
		try {
			_localctx = new AttributesDeclarationContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(36);
			match(ID_VAR);
			setState(37);
			match(COLON);
			setState(38);
			match(TYPE_IDENTIFIER);
			setState(41);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASSIGN) {
				{
				setState(39);
				match(ASSIGN);
				setState(40);
				expr(0);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FeatureContext extends ParserRuleContext {
		public FeatureContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_feature; }
	 
		public FeatureContext() { }
		public void copyFrom(FeatureContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class MethodDefContext extends FeatureContext {
		public TerminalNode ID_VAR() { return getToken(yaplParser.ID_VAR, 0); }
		public TerminalNode LPAREN() { return getToken(yaplParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(yaplParser.RPAREN, 0); }
		public TerminalNode COLON() { return getToken(yaplParser.COLON, 0); }
		public TerminalNode TYPE_IDENTIFIER() { return getToken(yaplParser.TYPE_IDENTIFIER, 0); }
		public TerminalNode LBRACE() { return getToken(yaplParser.LBRACE, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RBRACE() { return getToken(yaplParser.RBRACE, 0); }
		public List<FormalContext> formal() {
			return getRuleContexts(FormalContext.class);
		}
		public FormalContext formal(int i) {
			return getRuleContext(FormalContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(yaplParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(yaplParser.COMMA, i);
		}
		public MethodDefContext(FeatureContext ctx) { copyFrom(ctx); }
	}
	public static class AttrContext extends FeatureContext {
		public TerminalNode ID_VAR() { return getToken(yaplParser.ID_VAR, 0); }
		public TerminalNode COLON() { return getToken(yaplParser.COLON, 0); }
		public TerminalNode TYPE_IDENTIFIER() { return getToken(yaplParser.TYPE_IDENTIFIER, 0); }
		public TerminalNode ASSIGN() { return getToken(yaplParser.ASSIGN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public AttrContext(FeatureContext ctx) { copyFrom(ctx); }
	}

	public final FeatureContext feature() throws RecognitionException {
		FeatureContext _localctx = new FeatureContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_feature);
		int _la;
		try {
			setState(72);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				_localctx = new MethodDefContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(43);
				match(ID_VAR);
				setState(44);
				match(LPAREN);
				setState(55);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ID_VAR) {
					{
					{
					setState(45);
					formal();
					setState(50);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA) {
						{
						{
						setState(46);
						match(COMMA);
						setState(47);
						formal();
						}
						}
						setState(52);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					}
					setState(57);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(58);
				match(RPAREN);
				setState(59);
				match(COLON);
				setState(60);
				match(TYPE_IDENTIFIER);
				setState(61);
				match(LBRACE);
				setState(62);
				expr(0);
				setState(63);
				match(RBRACE);
				}
				break;
			case 2:
				_localctx = new AttrContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(65);
				match(ID_VAR);
				setState(66);
				match(COLON);
				setState(67);
				match(TYPE_IDENTIFIER);
				setState(70);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ASSIGN) {
					{
					setState(68);
					match(ASSIGN);
					setState(69);
					expr(0);
					}
				}

				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FormalContext extends ParserRuleContext {
		public TerminalNode ID_VAR() { return getToken(yaplParser.ID_VAR, 0); }
		public TerminalNode COLON() { return getToken(yaplParser.COLON, 0); }
		public TerminalNode TYPE_IDENTIFIER() { return getToken(yaplParser.TYPE_IDENTIFIER, 0); }
		public FormalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formal; }
	}

	public final FormalContext formal() throws RecognitionException {
		FormalContext _localctx = new FormalContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_formal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(74);
			match(ID_VAR);
			setState(75);
			match(COLON);
			setState(76);
			match(TYPE_IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class NewContext extends ExprContext {
		public TerminalNode NEW() { return getToken(yaplParser.NEW, 0); }
		public TerminalNode TYPE_IDENTIFIER() { return getToken(yaplParser.TYPE_IDENTIFIER, 0); }
		public NewContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class MinusContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode MINUS() { return getToken(yaplParser.MINUS, 0); }
		public MinusContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class MultContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode MULT() { return getToken(yaplParser.MULT, 0); }
		public MultContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class StringContext extends ExprContext {
		public TerminalNode STR_VAR() { return getToken(yaplParser.STR_VAR, 0); }
		public StringContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class IsvoidContext extends ExprContext {
		public TerminalNode ISVOID() { return getToken(yaplParser.ISVOID, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public IsvoidContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class FalseContext extends ExprContext {
		public TerminalNode FALSE() { return getToken(yaplParser.FALSE, 0); }
		public FalseContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class IntegerContext extends ExprContext {
		public TerminalNode INT_VAR() { return getToken(yaplParser.INT_VAR, 0); }
		public IntegerContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class LessContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode LESS_THAN() { return getToken(yaplParser.LESS_THAN, 0); }
		public LessContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class WhileContext extends ExprContext {
		public TerminalNode WHILE() { return getToken(yaplParser.WHILE, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode LOOP() { return getToken(yaplParser.LOOP, 0); }
		public TerminalNode POOL() { return getToken(yaplParser.POOL, 0); }
		public WhileContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class PlusContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode PLUS() { return getToken(yaplParser.PLUS, 0); }
		public PlusContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class DivContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode DIV() { return getToken(yaplParser.DIV, 0); }
		public DivContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class EqualContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(yaplParser.EQUAL, 0); }
		public EqualContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class NegativeContext extends ExprContext {
		public TerminalNode NEGATIVE() { return getToken(yaplParser.NEGATIVE, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public NegativeContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class NotContext extends ExprContext {
		public TerminalNode NOT() { return getToken(yaplParser.NOT, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public NotContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class ParenContext extends ExprContext {
		public TerminalNode LPAREN() { return getToken(yaplParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(yaplParser.RPAREN, 0); }
		public ParenContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class TrueContext extends ExprContext {
		public TerminalNode TRUE() { return getToken(yaplParser.TRUE, 0); }
		public TrueContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class BlockContext extends ExprContext {
		public TerminalNode LBRACE() { return getToken(yaplParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(yaplParser.RBRACE, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> SEMICOLON() { return getTokens(yaplParser.SEMICOLON); }
		public TerminalNode SEMICOLON(int i) {
			return getToken(yaplParser.SEMICOLON, i);
		}
		public BlockContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class LetContext extends ExprContext {
		public TerminalNode LET() { return getToken(yaplParser.LET, 0); }
		public List<Var_typescriptContext> var_typescript() {
			return getRuleContexts(Var_typescriptContext.class);
		}
		public Var_typescriptContext var_typescript(int i) {
			return getRuleContext(Var_typescriptContext.class,i);
		}
		public TerminalNode IN() { return getToken(yaplParser.IN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(yaplParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(yaplParser.COMMA, i);
		}
		public LetContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class FunctionCallContext extends ExprContext {
		public TerminalNode ID_VAR() { return getToken(yaplParser.ID_VAR, 0); }
		public TerminalNode LPAREN() { return getToken(yaplParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(yaplParser.RPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(yaplParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(yaplParser.COMMA, i);
		}
		public FunctionCallContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class IdContext extends ExprContext {
		public TerminalNode ID_VAR() { return getToken(yaplParser.ID_VAR, 0); }
		public IdContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class IfContext extends ExprContext {
		public TerminalNode IF() { return getToken(yaplParser.IF, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode THEN() { return getToken(yaplParser.THEN, 0); }
		public TerminalNode ELSE() { return getToken(yaplParser.ELSE, 0); }
		public TerminalNode FI() { return getToken(yaplParser.FI, 0); }
		public IfContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class Less_equalContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode LESS_EQUAL() { return getToken(yaplParser.LESS_EQUAL, 0); }
		public Less_equalContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class AssignContext extends ExprContext {
		public TerminalNode ID_VAR() { return getToken(yaplParser.ID_VAR, 0); }
		public TerminalNode ASSIGN() { return getToken(yaplParser.ASSIGN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public AssignContext(ExprContext ctx) { copyFrom(ctx); }
	}
	public static class MethodCallContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode PERIOD() { return getToken(yaplParser.PERIOD, 0); }
		public TerminalNode ID_VAR() { return getToken(yaplParser.ID_VAR, 0); }
		public TerminalNode LPAREN() { return getToken(yaplParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(yaplParser.RPAREN, 0); }
		public TerminalNode AT() { return getToken(yaplParser.AT, 0); }
		public TerminalNode TYPE_IDENTIFIER() { return getToken(yaplParser.TYPE_IDENTIFIER, 0); }
		public List<TerminalNode> COMMA() { return getTokens(yaplParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(yaplParser.COMMA, i);
		}
		public MethodCallContext(ExprContext ctx) { copyFrom(ctx); }
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 10;
		enterRecursionRule(_localctx, 10, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(151);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
			case 1:
				{
				_localctx = new FunctionCallContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(79);
				match(ID_VAR);
				setState(80);
				match(LPAREN);
				setState(91);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IF) | (1L << ISVOID) | (1L << WHILE) | (1L << NEW) | (1L << NOT) | (1L << LET) | (1L << TRUE) | (1L << FALSE) | (1L << LPAREN) | (1L << LBRACE) | (1L << NEGATIVE) | (1L << INT_VAR) | (1L << ID_VAR) | (1L << STR_VAR))) != 0)) {
					{
					{
					setState(81);
					expr(0);
					setState(86);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA) {
						{
						{
						setState(82);
						match(COMMA);
						setState(83);
						expr(0);
						}
						}
						setState(88);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					}
					setState(93);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(94);
				match(RPAREN);
				}
				break;
			case 2:
				{
				_localctx = new IfContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(95);
				match(IF);
				setState(96);
				expr(0);
				setState(97);
				match(THEN);
				setState(98);
				expr(0);
				setState(99);
				match(ELSE);
				setState(100);
				expr(0);
				setState(101);
				match(FI);
				}
				break;
			case 3:
				{
				_localctx = new WhileContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(103);
				match(WHILE);
				setState(104);
				expr(0);
				setState(105);
				match(LOOP);
				setState(106);
				expr(0);
				setState(107);
				match(POOL);
				}
				break;
			case 4:
				{
				_localctx = new BlockContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(109);
				match(LBRACE);
				setState(113); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(110);
					expr(0);
					setState(111);
					match(SEMICOLON);
					}
					}
					setState(115); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IF) | (1L << ISVOID) | (1L << WHILE) | (1L << NEW) | (1L << NOT) | (1L << LET) | (1L << TRUE) | (1L << FALSE) | (1L << LPAREN) | (1L << LBRACE) | (1L << NEGATIVE) | (1L << INT_VAR) | (1L << ID_VAR) | (1L << STR_VAR))) != 0) );
				setState(117);
				match(RBRACE);
				}
				break;
			case 5:
				{
				_localctx = new LetContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(119);
				match(LET);
				setState(120);
				var_typescript();
				setState(125);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(121);
					match(COMMA);
					setState(122);
					var_typescript();
					}
					}
					setState(127);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(128);
				match(IN);
				setState(129);
				expr(19);
				}
				break;
			case 6:
				{
				_localctx = new NewContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(131);
				match(NEW);
				setState(132);
				match(TYPE_IDENTIFIER);
				}
				break;
			case 7:
				{
				_localctx = new NegativeContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(133);
				match(NEGATIVE);
				setState(134);
				expr(17);
				}
				break;
			case 8:
				{
				_localctx = new IsvoidContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(135);
				match(ISVOID);
				setState(136);
				expr(16);
				}
				break;
			case 9:
				{
				_localctx = new NotContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(137);
				match(NOT);
				setState(138);
				expr(8);
				}
				break;
			case 10:
				{
				_localctx = new ParenContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(139);
				match(LPAREN);
				setState(140);
				expr(0);
				setState(141);
				match(RPAREN);
				}
				break;
			case 11:
				{
				_localctx = new IdContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(143);
				match(ID_VAR);
				}
				break;
			case 12:
				{
				_localctx = new IntegerContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(144);
				match(INT_VAR);
				}
				break;
			case 13:
				{
				_localctx = new StringContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(145);
				match(STR_VAR);
				}
				break;
			case 14:
				{
				_localctx = new TrueContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(146);
				match(TRUE);
				}
				break;
			case 15:
				{
				_localctx = new FalseContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(147);
				match(FALSE);
				}
				break;
			case 16:
				{
				_localctx = new AssignContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(148);
				match(ID_VAR);
				setState(149);
				match(ASSIGN);
				setState(150);
				expr(1);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(198);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(196);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
					case 1:
						{
						_localctx = new MultContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(153);
						if (!(precpred(_ctx, 15))) throw new FailedPredicateException(this, "precpred(_ctx, 15)");
						setState(154);
						match(MULT);
						setState(155);
						expr(16);
						}
						break;
					case 2:
						{
						_localctx = new DivContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(156);
						if (!(precpred(_ctx, 14))) throw new FailedPredicateException(this, "precpred(_ctx, 14)");
						setState(157);
						match(DIV);
						setState(158);
						expr(15);
						}
						break;
					case 3:
						{
						_localctx = new PlusContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(159);
						if (!(precpred(_ctx, 13))) throw new FailedPredicateException(this, "precpred(_ctx, 13)");
						setState(160);
						match(PLUS);
						setState(161);
						expr(14);
						}
						break;
					case 4:
						{
						_localctx = new MinusContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(162);
						if (!(precpred(_ctx, 12))) throw new FailedPredicateException(this, "precpred(_ctx, 12)");
						setState(163);
						match(MINUS);
						setState(164);
						expr(13);
						}
						break;
					case 5:
						{
						_localctx = new Less_equalContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(165);
						if (!(precpred(_ctx, 11))) throw new FailedPredicateException(this, "precpred(_ctx, 11)");
						setState(166);
						match(LESS_EQUAL);
						setState(167);
						expr(12);
						}
						break;
					case 6:
						{
						_localctx = new LessContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(168);
						if (!(precpred(_ctx, 10))) throw new FailedPredicateException(this, "precpred(_ctx, 10)");
						setState(169);
						match(LESS_THAN);
						setState(170);
						expr(11);
						}
						break;
					case 7:
						{
						_localctx = new EqualContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(171);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(172);
						match(EQUAL);
						setState(173);
						expr(10);
						}
						break;
					case 8:
						{
						_localctx = new MethodCallContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(174);
						if (!(precpred(_ctx, 23))) throw new FailedPredicateException(this, "precpred(_ctx, 23)");
						setState(177);
						_errHandler.sync(this);
						_la = _input.LA(1);
						if (_la==AT) {
							{
							setState(175);
							match(AT);
							setState(176);
							match(TYPE_IDENTIFIER);
							}
						}

						setState(179);
						match(PERIOD);
						setState(180);
						match(ID_VAR);
						setState(181);
						match(LPAREN);
						setState(192);
						_errHandler.sync(this);
						_la = _input.LA(1);
						while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IF) | (1L << ISVOID) | (1L << WHILE) | (1L << NEW) | (1L << NOT) | (1L << LET) | (1L << TRUE) | (1L << FALSE) | (1L << LPAREN) | (1L << LBRACE) | (1L << NEGATIVE) | (1L << INT_VAR) | (1L << ID_VAR) | (1L << STR_VAR))) != 0)) {
							{
							{
							setState(182);
							expr(0);
							setState(187);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==COMMA) {
								{
								{
								setState(183);
								match(COMMA);
								setState(184);
								expr(0);
								}
								}
								setState(189);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							}
							}
							setState(194);
							_errHandler.sync(this);
							_la = _input.LA(1);
						}
						setState(195);
						match(RPAREN);
						}
						break;
					}
					} 
				}
				setState(200);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 5:
			return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 15);
		case 1:
			return precpred(_ctx, 14);
		case 2:
			return precpred(_ctx, 13);
		case 3:
			return precpred(_ctx, 12);
		case 4:
			return precpred(_ctx, 11);
		case 5:
			return precpred(_ctx, 10);
		case 6:
			return precpred(_ctx, 9);
		case 7:
			return precpred(_ctx, 23);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\60\u00cc\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\3\2\3\2\3\2\6\2\22\n\2\r\2\16"+
		"\2\23\3\3\3\3\3\3\3\3\5\3\32\n\3\3\3\3\3\3\3\3\3\7\3 \n\3\f\3\16\3#\13"+
		"\3\3\3\3\3\3\4\3\4\3\4\3\4\3\4\5\4,\n\4\3\5\3\5\3\5\3\5\3\5\7\5\63\n\5"+
		"\f\5\16\5\66\13\5\7\58\n\5\f\5\16\5;\13\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5"+
		"\3\5\3\5\3\5\3\5\3\5\5\5I\n\5\5\5K\n\5\3\6\3\6\3\6\3\6\3\7\3\7\3\7\3\7"+
		"\3\7\3\7\7\7W\n\7\f\7\16\7Z\13\7\7\7\\\n\7\f\7\16\7_\13\7\3\7\3\7\3\7"+
		"\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\6\7t"+
		"\n\7\r\7\16\7u\3\7\3\7\3\7\3\7\3\7\3\7\7\7~\n\7\f\7\16\7\u0081\13\7\3"+
		"\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7"+
		"\3\7\3\7\3\7\3\7\3\7\5\7\u009a\n\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7"+
		"\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\5\7\u00b4"+
		"\n\7\3\7\3\7\3\7\3\7\3\7\3\7\7\7\u00bc\n\7\f\7\16\7\u00bf\13\7\7\7\u00c1"+
		"\n\7\f\7\16\7\u00c4\13\7\3\7\7\7\u00c7\n\7\f\7\16\7\u00ca\13\7\3\7\2\3"+
		"\f\b\2\4\6\b\n\f\2\2\2\u00eb\2\21\3\2\2\2\4\25\3\2\2\2\6&\3\2\2\2\bJ\3"+
		"\2\2\2\nL\3\2\2\2\f\u0099\3\2\2\2\16\17\5\4\3\2\17\20\7\32\2\2\20\22\3"+
		"\2\2\2\21\16\3\2\2\2\22\23\3\2\2\2\23\21\3\2\2\2\23\24\3\2\2\2\24\3\3"+
		"\2\2\2\25\26\7\3\2\2\26\31\7/\2\2\27\30\7\b\2\2\30\32\7/\2\2\31\27\3\2"+
		"\2\2\31\32\3\2\2\2\32\33\3\2\2\2\33!\7\27\2\2\34\35\5\b\5\2\35\36\7\32"+
		"\2\2\36 \3\2\2\2\37\34\3\2\2\2 #\3\2\2\2!\37\3\2\2\2!\"\3\2\2\2\"$\3\2"+
		"\2\2#!\3\2\2\2$%\7\30\2\2%\5\3\2\2\2&\'\7.\2\2\'(\7\31\2\2(+\7/\2\2)*"+
		"\7)\2\2*,\5\f\7\2+)\3\2\2\2+,\3\2\2\2,\7\3\2\2\2-.\7.\2\2.9\7\25\2\2/"+
		"\64\5\n\6\2\60\61\7\33\2\2\61\63\5\n\6\2\62\60\3\2\2\2\63\66\3\2\2\2\64"+
		"\62\3\2\2\2\64\65\3\2\2\2\658\3\2\2\2\66\64\3\2\2\2\67/\3\2\2\28;\3\2"+
		"\2\29\67\3\2\2\29:\3\2\2\2:<\3\2\2\2;9\3\2\2\2<=\7\26\2\2=>\7\31\2\2>"+
		"?\7/\2\2?@\7\27\2\2@A\5\f\7\2AB\7\30\2\2BK\3\2\2\2CD\7.\2\2DE\7\31\2\2"+
		"EH\7/\2\2FG\7)\2\2GI\5\f\7\2HF\3\2\2\2HI\3\2\2\2IK\3\2\2\2J-\3\2\2\2J"+
		"C\3\2\2\2K\t\3\2\2\2LM\7.\2\2MN\7\31\2\2NO\7/\2\2O\13\3\2\2\2PQ\b\7\1"+
		"\2QR\7.\2\2R]\7\25\2\2SX\5\f\7\2TU\7\33\2\2UW\5\f\7\2VT\3\2\2\2WZ\3\2"+
		"\2\2XV\3\2\2\2XY\3\2\2\2Y\\\3\2\2\2ZX\3\2\2\2[S\3\2\2\2\\_\3\2\2\2][\3"+
		"\2\2\2]^\3\2\2\2^`\3\2\2\2_]\3\2\2\2`\u009a\7\26\2\2ab\7\6\2\2bc\5\f\7"+
		"\2cd\7\f\2\2de\5\f\7\2ef\7\4\2\2fg\5\f\7\2gh\7\5\2\2h\u009a\3\2\2\2ij"+
		"\7\r\2\2jk\5\f\7\2kl\7\n\2\2lm\5\f\7\2mn\7\13\2\2n\u009a\3\2\2\2os\7\27"+
		"\2\2pq\5\f\7\2qr\7\32\2\2rt\3\2\2\2sp\3\2\2\2tu\3\2\2\2us\3\2\2\2uv\3"+
		"\2\2\2vw\3\2\2\2wx\7\30\2\2x\u009a\3\2\2\2yz\7\20\2\2z\177\5\6\4\2{|\7"+
		"\33\2\2|~\5\6\4\2}{\3\2\2\2~\u0081\3\2\2\2\177}\3\2\2\2\177\u0080\3\2"+
		"\2\2\u0080\u0082\3\2\2\2\u0081\177\3\2\2\2\u0082\u0083\7\7\2\2\u0083\u0084"+
		"\5\f\7\25\u0084\u009a\3\2\2\2\u0085\u0086\7\16\2\2\u0086\u009a\7/\2\2"+
		"\u0087\u0088\7\35\2\2\u0088\u009a\5\f\7\23\u0089\u008a\7\t\2\2\u008a\u009a"+
		"\5\f\7\22\u008b\u008c\7\17\2\2\u008c\u009a\5\f\7\n\u008d\u008e\7\25\2"+
		"\2\u008e\u008f\5\f\7\2\u008f\u0090\7\26\2\2\u0090\u009a\3\2\2\2\u0091"+
		"\u009a\7.\2\2\u0092\u009a\7-\2\2\u0093\u009a\7\60\2\2\u0094\u009a\7\21"+
		"\2\2\u0095\u009a\7\22\2\2\u0096\u0097\7.\2\2\u0097\u0098\7)\2\2\u0098"+
		"\u009a\5\f\7\3\u0099P\3\2\2\2\u0099a\3\2\2\2\u0099i\3\2\2\2\u0099o\3\2"+
		"\2\2\u0099y\3\2\2\2\u0099\u0085\3\2\2\2\u0099\u0087\3\2\2\2\u0099\u0089"+
		"\3\2\2\2\u0099\u008b\3\2\2\2\u0099\u008d\3\2\2\2\u0099\u0091\3\2\2\2\u0099"+
		"\u0092\3\2\2\2\u0099\u0093\3\2\2\2\u0099\u0094\3\2\2\2\u0099\u0095\3\2"+
		"\2\2\u0099\u0096\3\2\2\2\u009a\u00c8\3\2\2\2\u009b\u009c\f\21\2\2\u009c"+
		"\u009d\7!\2\2\u009d\u00c7\5\f\7\22\u009e\u009f\f\20\2\2\u009f\u00a0\7"+
		"\"\2\2\u00a0\u00c7\5\f\7\21\u00a1\u00a2\f\17\2\2\u00a2\u00a3\7\37\2\2"+
		"\u00a3\u00c7\5\f\7\20\u00a4\u00a5\f\16\2\2\u00a5\u00a6\7 \2\2\u00a6\u00c7"+
		"\5\f\7\17\u00a7\u00a8\f\r\2\2\u00a8\u00a9\7$\2\2\u00a9\u00c7\5\f\7\16"+
		"\u00aa\u00ab\f\f\2\2\u00ab\u00ac\7#\2\2\u00ac\u00c7\5\f\7\r\u00ad\u00ae"+
		"\f\13\2\2\u00ae\u00af\7\'\2\2\u00af\u00c7\5\f\7\f\u00b0\u00b3\f\31\2\2"+
		"\u00b1\u00b2\7\36\2\2\u00b2\u00b4\7/\2\2\u00b3\u00b1\3\2\2\2\u00b3\u00b4"+
		"\3\2\2\2\u00b4\u00b5\3\2\2\2\u00b5\u00b6\7\34\2\2\u00b6\u00b7\7.\2\2\u00b7"+
		"\u00c2\7\25\2\2\u00b8\u00bd\5\f\7\2\u00b9\u00ba\7\33\2\2\u00ba\u00bc\5"+
		"\f\7\2\u00bb\u00b9\3\2\2\2\u00bc\u00bf\3\2\2\2\u00bd\u00bb\3\2\2\2\u00bd"+
		"\u00be\3\2\2\2\u00be\u00c1\3\2\2\2\u00bf\u00bd\3\2\2\2\u00c0\u00b8\3\2"+
		"\2\2\u00c1\u00c4\3\2\2\2\u00c2\u00c0\3\2\2\2\u00c2\u00c3\3\2\2\2\u00c3"+
		"\u00c5\3\2\2\2\u00c4\u00c2\3\2\2\2\u00c5\u00c7\7\26\2\2\u00c6\u009b\3"+
		"\2\2\2\u00c6\u009e\3\2\2\2\u00c6\u00a1\3\2\2\2\u00c6\u00a4\3\2\2\2\u00c6"+
		"\u00a7\3\2\2\2\u00c6\u00aa\3\2\2\2\u00c6\u00ad\3\2\2\2\u00c6\u00b0\3\2"+
		"\2\2\u00c7\u00ca\3\2\2\2\u00c8\u00c6\3\2\2\2\u00c8\u00c9\3\2\2\2\u00c9"+
		"\r\3\2\2\2\u00ca\u00c8\3\2\2\2\24\23\31!+\649HJX]u\177\u0099\u00b3\u00bd"+
		"\u00c2\u00c6\u00c8";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}